const options = {
  client: "mysql",
  connection: {
    host: "127.0.0.1",
    port: 3306,
    user: "coder",
    password: "zgOXd1Js)H_8!jh5",
    database: "test",
  },
};

module.exports = {
  options,
};
