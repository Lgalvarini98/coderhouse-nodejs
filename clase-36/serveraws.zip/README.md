1° - Asignar los datos que correspondan en el archivo "config.js" dentro de la carpeta "options"
2° - Crear base de datos en XAMPP con el nombre que asignado en "config.js"
3° - Ejecutar "npm run build" para que se cree la tabla en la base de datos
4° - Agregar los valores al archivo .env segun corresponda (ruta donde guardamos el archivo que se descarga al hacer click en "Generar nueva clave privada" en firebase y la ruta que nos da mongo atlas)
5° - Ejecutar "npm start"
